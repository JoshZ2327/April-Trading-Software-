// Backend API Integration
const API_URL = "http://your-backend-url/api/portfolio";

// Wallet Connection
document.getElementById('connectWalletButton').addEventListener('click', async () => {
    if (window.solana && window.solana.isPhantom) {
        try {
            const response = await window.solana.connect();
            console.log('Wallet Connected:', response.publicKey.toString());
            alert('Wallet connected successfully!');
        } catch (error) {
            console.error('Wallet connection failed:', error);
        }
    } else {
        alert('Phantom Wallet not installed!');
    }
});

// Fetch Portfolio Data
async function fetchPortfolio() {
    try {
        const response = await fetch(API_URL);
        const data = await response.json();
        displayPortfolio(data);
    } catch (error) {
        console.error('Error fetching portfolio data:', error);
    }
}

// Display Portfolio
function displayPortfolio(data) {
    const container = document.getElementById('portfolioData');
    container.innerHTML = data.map(item => `<p>${item.token}: ${item.amount}</p>`).join('');
}

window.onload = fetchPortfolio;
